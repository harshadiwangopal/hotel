const API_URL = "http://localhost:3000/reminders";

document.getElementById('reminderForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const reminder = {
        medicine_name: document.getElementById('medicineName').value,
        dosage: document.getElementById('dosage').value,
        time: document.getElementById('time').value,
        user_phone: document.getElementById('phone').value
    };

    await fetch(API_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(reminder) });
    loadReminders();
});

async function loadReminders() {
    const res = await fetch(API_URL);
    const data = await res.json();
    
    document.getElementById('reminderList').innerHTML = data.map(reminder => `
        <tr>
            <td>${reminder.medicine_name}</td>
            <td>${reminder.dosage}</td>
            <td>${reminder.time}</td>
            <td>${reminder.user_phone}</td>
            <td>
                <button onclick="deleteReminder(${reminder.id})">Delete</button>
            </td>
        </tr>
    `).join("");
}

async function deleteReminder(id) {
    await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    loadReminders();
}

loadReminders();
