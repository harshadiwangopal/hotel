const express = require('express');
const db = require('../config/db');
const router = express.Router();

// ✅ Create Reminder
router.post('/', (req, res) => {
    const { medicine_name, dosage, time, user_phone } = req.body;
    const sql = "INSERT INTO reminders (medicine_name, dosage, time, user_phone) VALUES (?, ?, ?, ?)";
    
    db.query(sql, [medicine_name, dosage, time, user_phone], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ message: "Reminder added successfully!", id: result.insertId });
    });
});

// ✅ Get All Reminders
router.get('/', (req, res) => {
    db.query("SELECT * FROM reminders", (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// ✅ Update Reminder
router.put('/:id', (req, res) => {
    const { medicine_name, dosage, time, user_phone } = req.body;
    const sql = "UPDATE reminders SET medicine_name=?, dosage=?, time=?, user_phone=? WHERE id=?";
    
    db.query(sql, [medicine_name, dosage, time, user_phone, req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Reminder updated successfully!" });
    });
});

// ✅ Delete Reminder
router.delete('/:id', (req, res) => {
    const sql = "DELETE FROM reminders WHERE id=?";
    
    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Reminder deleted successfully!" });
    });
});

module.exports = router;
